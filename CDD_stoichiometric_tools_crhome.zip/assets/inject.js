const EVENT_SOURCE = "CDD_STOICH_TOOLS";
const EVENTS = {
  PRINT_REQUEST: "PRINT_REQUEST"
};
function post(type, payload) {
  window.postMessage(
    {
      source: EVENT_SOURCE,
      type,
      payload
    },
    "*"
  );
}
function normalizeFeatures(featureMap) {
  if (!featureMap) return [];
  if (Array.isArray(featureMap)) return featureMap;
  if (typeof featureMap === "object") return Object.values(featureMap);
  return [];
}
function isElnPayload(payload) {
  return !!(payload && typeof payload === "object" && payload.eln_entry && typeof payload.eln_entry === "object" && payload.eln_entry.feature_map && typeof payload.eln_entry.feature_map === "object");
}
function getReactionFeatures(payload) {
  const features = normalizeFeatures(payload?.eln_entry?.feature_map);
  return features.filter(
    (f) => f?.type === "reaction" && f?.data?.stoichiometryTable
  );
}
function hasAnyReactionFeature(payload) {
  const features = normalizeFeatures(payload?.eln_entry?.feature_map);
  return features.some((f) => f?.type === "reaction");
}
function createTextParser(processJsonPayload2) {
  return function tryParseText2(text) {
    if (!text || typeof text !== "string") return;
    try {
      processJsonPayload2(JSON.parse(text));
    } catch (_) {
    }
  };
}
function shortenLocation(value) {
  if (value == null) return "";
  const parts = String(value).split(/\s*>\s*/).map((part) => part.trim()).filter(Boolean);
  return parts.length >= 2 ? `${parts.at(-2)} > ${parts.at(-1)}` : parts[0] || "";
}
function normalizeFieldMap(fieldMap) {
  if (!fieldMap || typeof fieldMap !== "object") return {};
  return fieldMap;
}
function getFieldValueCaseInsensitive(fieldMap, candidateNames = []) {
  const map = normalizeFieldMap(fieldMap);
  const entries = Object.entries(map);
  for (const candidate of candidateNames) {
    const normalizedCandidate = String(candidate).trim().toLowerCase();
    for (const [key, value] of entries) {
      if (String(key).trim().toLowerCase() === normalizedCandidate) {
        if (value && typeof value === "object" && "value" in value) {
          return value.value;
        }
        return value;
      }
    }
  }
  return null;
}
function resolveRowName(row) {
  if (row?.sample?.sample_identifier) {
    return String(row.sample.sample_identifier).trim();
  }
  const fallback = row?.sample?.name || row?.iupacName || row?.moleculeName || row?.batch?.name || "Unnamed sample";
  return String(fallback).trim();
}
function resolveRowLocation(row) {
  const rawLocation = row?.sample?.location?.value ?? row?.sample?.location ?? null;
  if (!rawLocation) return null;
  let normalized = null;
  if (typeof rawLocation === "string") {
    normalized = rawLocation;
  } else if (typeof rawLocation === "object") {
    normalized = rawLocation.value || rawLocation.name || rawLocation.label || null;
  }
  if (!normalized || typeof normalized !== "string") return null;
  return shortenLocation(normalized);
}
function resolveBatchFields(row) {
  const batchFields = row?.sample?.batch_fields || row?.batch_fields || row?.batch?.batch_fields || row?.sample?.batch?.batch_fields || {};
  const purity = getFieldValueCaseInsensitive(batchFields, [
    "Purity (%)",
    "Purity [%]",
    "Purity[%]",
    "Purity %",
    "Purity"
  ]);
  const internalID = getFieldValueCaseInsensitive(batchFields, [
    "Internal ID",
    "*Internal ID"
  ]);
  const density = getFieldValueCaseInsensitive(batchFields, [
    "Density [g/mL]",
    "Density[g/mL]",
    "Density"
  ]);
  return {
    purity,
    density,
    internalID
  };
}
function resolveSampleFields(row) {
  const sampleFields = row?.sample?.inventory_sample_fields || row?.sample?.sample_fields || row?.sample?.fields || row?.sample_fields || {};
  const concentration = getFieldValueCaseInsensitive(sampleFields, [
    "Concentration",
    "*Concentration"
  ]);
  const solvent = getFieldValueCaseInsensitive(sampleFields, [
    "*Solvent",
    "Solvent",
    "Buffer",
    "*Buffer",
    "*Solvent/Buffer/Medium",
    "Solvent/Buffer/Medium",
    "Solvent/Buffer",
    "Solvent/Medium",
    "Buffer/Medium",
    "Buffer/Solvent",
    "Buffer/Medium",
    "Medium/Solvent",
    "Medium/Buffer",
    "Medium"
  ]);
  const concentrationUnits = getFieldValueCaseInsensitive(sampleFields, [
    "Concentration units",
    "Concentration Units",
    "Concentration unit",
    "Concentration Unit",
    "*Concentration Unit"
  ]);
  return {
    concentration,
    concentrationUnits,
    solvent
  };
}
function extractRowsFromReactionFeature(feature, reactionIndex) {
  const stoichTable = feature?.data?.stoichiometryTable;
  const rows = Array.isArray(stoichTable?.rows) ? stoichTable.rows : [];
  const output = [];
  const seen = /* @__PURE__ */ new Set();
  for (const row of rows) {
    if (!row?.sample) continue;
    const rowUid = row?.uid ?? null;
    const sampleId = row?.sample?.id ?? row?.sampleId ?? row?.sample_id ?? null;
    const dedupeKey = `${reactionIndex}::${rowUid ?? "no-row"}::${sampleId ?? "no-sample"}`;
    if (seen.has(dedupeKey)) continue;
    seen.add(dedupeKey);
    const { purity, density, internalID } = resolveBatchFields(row);
    const { concentration, concentrationUnits, solvent } = resolveSampleFields(row);
    output.push({
      reactionIndex,
      reactionLabel: `Reaction ${reactionIndex + 1}`,
      featureId: feature?.id ?? null,
      rowUid,
      role: row?.role ?? null,
      sampleId,
      name: resolveRowName(row),
      location: resolveRowLocation(row),
      purity,
      density,
      concentration,
      concentrationUnits,
      internalID,
      solvent
    });
  }
  return output;
}
function extractAllReactionRows(payload) {
  const reactionFeatures = getReactionFeatures(payload);
  const allRows = [];
  reactionFeatures.forEach((feature, index) => {
    const rows = extractRowsFromReactionFeature(feature, index);
    allRows.push(...rows);
  });
  return {
    reactionCount: reactionFeatures.length,
    samples: allRows
  };
}
const PRINT_STATE = {
  lastNonEmptyDepletedIdentifiers: [],
  lastNonEmptyReactionPayloads: []
};
function getReactionTitle(payload) {
  return payload?.eln_entry?.title || payload?.eln_entry?.displayTitle || "Stoichiometry Sheet";
}
function resolveDisplayName(row) {
  return row?.sample?.name || row?.name || row?.iupacName || row?.moleculeName || row?.batch?.name || "Unnamed";
}
function formatValue(value) {
  if (value == null || value === "") return "";
  if (typeof value === "number") return String(value);
  return String(value).trim();
}
function resolveRowData(row) {
  const amount = row?.amount ?? row?.mass ?? row?.value ?? "";
  const amountUnit = row?.amountUnit ?? row?.unit ?? row?.units ?? "";
  const desiredEq = row?.desiredEq ?? row?.equivalents ?? row?.eq ?? row?.equivalent ?? "";
  const mol = row?.mole ?? "";
  const mw = row?.mw ?? row?.molecularWeight ?? row?.formulaWeight ?? "";
  const exactMass = row?.exactMass ?? "";
  const volume = row?.volume ?? "";
  const density = row?.density ?? row?.sample?.density ?? "";
  const boilingPoint = row?.boilingPoint ?? "";
  const effectiveMole = row?.moleffective ?? row?.effectiveMole ?? "";
  const limitingReagent = !!(row?.limitingReagent ?? row?.limiting);
  const yieldValue = row?.yield ?? "";
  const location = row?.sample?.location?.value ?? row?.sample?.location ?? "";
  const subtitle = row?.subtitle ?? row?.iupacName ?? "";
  return {
    name: resolveDisplayName(row),
    formulaWeight: formatValue(mw),
    molecularWeight: formatValue(mw),
    exactMass: formatValue(exactMass),
    density: formatValue(density),
    boilingPoint: formatValue(boilingPoint),
    mass: formatValue(amount),
    amountUnit: formatValue(amountUnit),
    volume: formatValue(volume),
    equivalent: formatValue(desiredEq),
    mole: formatValue(mol),
    effectiveMole: formatValue(effectiveMole),
    limitingReagent,
    yield: formatValue(yieldValue),
    location: formatValue(location),
    subtitle: formatValue(subtitle),
    depleted: !!row?.sample?.depleted
  };
}
function extractRows(feature) {
  const stoichTable = feature?.data?.stoichiometryTable;
  const rows = Array.isArray(stoichTable?.rows) ? stoichTable.rows : [];
  return rows.filter((row) => {
    const role = String(row?.role || "").toLowerCase();
    const rowType = String(row?.rowType || "").toLowerCase();
    return role !== "product" && rowType !== "product";
  }).map(resolveRowData);
}
function extractDepletedIdentifiers(payload) {
  const reactionFeatures = getReactionFeatures(payload);
  const identifiers = /* @__PURE__ */ new Set();
  for (const feature of reactionFeatures) {
    const stoichTable = feature?.data?.stoichiometryTable;
    const samples = stoichTable?.samples || {};
    for (const [key, arr] of Object.entries(samples)) {
      if (!Array.isArray(arr)) continue;
      for (const sample of arr) {
        if (sample?.depleted !== true) continue;
        const identifier = sample?.sample_identifier || sample?.name || sample?.id;
        if (identifier) {
          identifiers.add(String(identifier).trim());
        }
      }
    }
  }
  return Array.from(identifiers);
}
function extractPrintData(payload) {
  const reactionFeatures = getReactionFeatures(payload);
  const experimentIdentifier = payload?.eln_entry?.identifier || null;
  const reactionPayloads = reactionFeatures.map((feature, reactionIndex) => ({
    reactionIndex,
    title: getReactionTitle(payload),
    featureId: feature?.id ?? null,
    rows: extractRows(feature),
    identifier: experimentIdentifier,
    reactionImage: feature?.data?.reactionImage || feature?.data?.image || feature?.data?.reaction_scheme || null
  }));
  const depletedIdentifiers = extractDepletedIdentifiers(payload);
  if (reactionPayloads.length) {
    PRINT_STATE.lastNonEmptyReactionPayloads = reactionPayloads;
  }
  if (depletedIdentifiers.length) {
    PRINT_STATE.lastNonEmptyDepletedIdentifiers = depletedIdentifiers;
  }
  return {
    reactionPayloads: reactionPayloads.length ? reactionPayloads : PRINT_STATE.lastNonEmptyReactionPayloads,
    depletedIdentifiers: depletedIdentifiers.length ? depletedIdentifiers : PRINT_STATE.lastNonEmptyDepletedIdentifiers
  };
}
function installFetchHook(processJsonPayload2, tryParseText2) {
  const origFetch = window.fetch;
  window.fetch = async function(...args) {
    const res = await origFetch.apply(this, args);
    let clone;
    try {
      clone = res.clone();
    } catch {
      return res;
    }
    try {
      const contentType = clone.headers.get("content-type") || "";
      if (contentType.includes("application/json") || contentType.includes("text/json")) {
        try {
          const json = await clone.json();
          processJsonPayload2(json);
        } catch {
          tryParseText2(await clone.text());
        }
      } else {
        tryParseText2(await clone.text());
      }
    } catch (err) {
      console.debug("[CDD Stoich Tools] fetch parse failed", err);
    }
    return res;
  };
}
function installXhrHook(tryParseText2) {
  const origOpen = XMLHttpRequest.prototype.open;
  const origSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function(method, url, ...rest) {
    this.__cdd_url = url;
    return origOpen.call(this, method, url, ...rest);
  };
  XMLHttpRequest.prototype.send = function(...args) {
    this.addEventListener("load", function() {
      try {
        if (this.responseType && this.responseType !== "" && this.responseType !== "text") {
          return;
        }
        tryParseText2(this.responseText);
      } catch (err) {
        console.debug("[CDD Stoich Tools] xhr parse failed", err);
      }
    });
    return origSend.apply(this, args);
  };
}
function waitForImages(doc, callback) {
  const images = Array.from(doc.images || []);
  if (!images.length) {
    setTimeout(callback, 200);
    return;
  }
  let remaining = images.length;
  const done = () => {
    remaining -= 1;
    if (remaining <= 0) {
      setTimeout(callback, 200);
    }
  };
  images.forEach((img) => {
    if (img.complete) {
      done();
      return;
    }
    img.addEventListener("load", done, { once: true });
    img.addEventListener("error", done, { once: true });
  });
}
function printHtmlViaIframe(html) {
  const oldFrame = document.getElementById("cdd-stoich-print-frame");
  if (oldFrame) {
    oldFrame.remove();
  }
  const iframe = document.createElement("iframe");
  iframe.id = "cdd-stoich-print-frame";
  iframe.style.position = "fixed";
  iframe.style.right = "0";
  iframe.style.bottom = "0";
  iframe.style.width = "0";
  iframe.style.height = "0";
  iframe.style.border = "0";
  iframe.style.opacity = "0";
  iframe.setAttribute("aria-hidden", "true");
  document.documentElement.appendChild(iframe);
  const doc = iframe.contentDocument || iframe.contentWindow?.document;
  if (!doc) {
    console.warn("[CDD Stoich Tools] print iframe document unavailable");
    iframe.remove();
    return;
  }
  doc.open();
  doc.write(html);
  doc.close();
  waitForImages(doc, () => {
    try {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
    } catch (err) {
      console.warn("[CDD Stoich Tools] print failed", err);
    }
    setTimeout(() => {
      iframe.remove();
    }, 1500);
  });
}
function installPrintDispatcher() {
  if (window.__CDD_STOICH_TOOLS_PRINT_DISPATCHER__) return;
  window.__CDD_STOICH_TOOLS_PRINT_DISPATCHER__ = true;
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.source !== EVENT_SOURCE) return;
    if (data.type !== EVENTS.PRINT_REQUEST) return;
    const html = data.payload?.html;
    if (!html || typeof html !== "string") {
      console.warn("[CDD Stoich Tools] invalid print payload");
      return;
    }
    printHtmlViaIframe(html);
  });
}
function processJsonPayload(data) {
  if (!data || typeof data !== "object") return;
  if (!isElnPayload(data)) return;
  const hasReaction = hasAnyReactionFeature(data);
  post("REACTION_VISIBILITY", {
    visible: hasReaction
  });
  if (!hasReaction) return;
  try {
    const sampleResult = extractAllReactionRows(data);
    if (sampleResult?.samples?.length) {
      post("SAMPLE_DATA", sampleResult);
    }
  } catch (err) {
    console.warn("[CDD Stoich Tools] sample parse failed", err);
  }
  try {
    const printResult = extractPrintData(data);
    post("PRINT_DATA", printResult);
  } catch (err) {
    console.warn("[CDD Stoich Tools] print parse failed", err);
  }
}
const tryParseText = createTextParser(processJsonPayload);
(() => {
  if (window.__CDD_STOICH_TOOLS_HOOKED__) return;
  window.__CDD_STOICH_TOOLS_HOOKED__ = true;
  console.log("[CDD Stoich Tools] inject main loaded");
  installPrintDispatcher();
  installFetchHook(processJsonPayload, tryParseText);
  installXhrHook(tryParseText);
})();
