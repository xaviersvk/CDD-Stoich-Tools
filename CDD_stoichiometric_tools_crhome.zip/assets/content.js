const PANEL_ID = "cdd-stoich-panel";
const INJECT_SCRIPT_ID = "cdd-stoich-tools-inject";
const INJECT_BUNDLE_PATH = "assets/inject.js";
const REACTION_COLORS = [
  {
    border: "#38bdf8",
    badgeBg: "rgba(56, 189, 248, 0.18)",
    badgeText: "#bae6fd",
    glow: "rgba(56, 189, 248, 0.22)"
  },
  {
    border: "#34d399",
    badgeBg: "rgba(52, 211, 153, 0.18)",
    badgeText: "#a7f3d0",
    glow: "rgba(52, 211, 153, 0.22)"
  },
  {
    border: "#f59e0b",
    badgeBg: "rgba(245, 158, 11, 0.18)",
    badgeText: "#fde68a",
    glow: "rgba(245, 158, 11, 0.22)"
  },
  {
    border: "#a78bfa",
    badgeBg: "rgba(167, 139, 250, 0.18)",
    badgeText: "#ddd6fe",
    glow: "rgba(167, 139, 250, 0.22)"
  }
];
function injectPageScript() {
  if (document.getElementById(INJECT_SCRIPT_ID)) return;
  const runtime = typeof browser !== "undefined" && browser?.runtime?.getURL ? browser.runtime : chrome.runtime;
  const script = document.createElement("script");
  script.id = INJECT_SCRIPT_ID;
  script.src = runtime.getURL(INJECT_BUNDLE_PATH);
  script.onload = () => script.remove();
  (document.head || document.documentElement).appendChild(script);
}
const STATE = {
  lastUrl: location.href,
  hasReactionFeature: false,
  isKetcherOpen: false,
  lastPayload: null,
  // sample panel payload
  reactionPayloads: [],
  // print payloads per reaction
  depletedIdentifiers: /* @__PURE__ */ new Set()
};
function resetState() {
  STATE.hasReactionFeature = false;
  STATE.lastPayload = null;
  STATE.reactionPayloads = [];
  STATE.depletedIdentifiers = /* @__PURE__ */ new Set();
}
async function copyText(text) {
  if (!text) return false;
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch (err) {
    console.warn("[CDD Stoich Tools] Clipboard write failed:", err);
    return false;
  }
}
async function copyTextWithFeedback(element, text, successLabel = "Copied") {
  if (!element || !text) return false;
  const originalText = element.textContent;
  const originalBg = element.style.background;
  const ok = await copyText(text);
  if (!ok) return false;
  element.textContent = successLabel;
  element.style.background = "rgba(34,197,94,0.18)";
  setTimeout(() => {
    element.textContent = originalText;
    element.style.background = originalBg;
  }, 700);
  return true;
}
function isElnEntryPage() {
  const path = location.pathname || "";
  return /eln/i.test(path) || /entry/i.test(path);
}
function getPanel() {
  return document.getElementById("cdd-stoich-panel");
}
function isKetcherDialogOpen() {
  return !!document.querySelector(
    '[role="dialog"], .dialog, .modal, .ketcher, iframe[src*="ketcher"]'
  );
}
function updatePanelVisibilityForOverlays() {
  const panel = getPanel();
  if (!panel) return;
  const open = isKetcherDialogOpen();
  STATE.isKetcherOpen = open;
  panel.style.display = open ? "none" : "";
}
function watchKetcherDialog() {
  const observer = new MutationObserver(() => {
    updatePanelVisibilityForOverlays();
  });
  observer.observe(document.body, {
    childList: true,
    subtree: true,
    attributes: false
  });
  updatePanelVisibilityForOverlays();
}
function escapeHtml(value) {
  return String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}
const EVENT_SOURCE = "CDD_STOICH_TOOLS";
function printPanel() {
  const payload = STATE.lastPayload;
  if (!payload?.samples?.length) {
    alert("No sample data available.");
    return;
  }
  const rowsHtml = payload.samples.map((sample) => `
        <tr>
            <td>${escapeHtml(sample.reactionLabel || "")}</td>
            <td>${escapeHtml(sample.name || "")}</td>
            <td>${escapeHtml(sample.location || "")}</td>
            <td>${escapeHtml(sample.concentration || "")}</td>
            <td>${escapeHtml(sample.purity || "")}</td>
            <td>${escapeHtml(sample.solvent || "")}</td>
            <td>${escapeHtml(sample.internalID || "")}</td>
        </tr>
    `).join("");
  const html = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CDD Samples</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 24px;
            color: #111;
        }
        h1 {
            margin-bottom: 16px;
            font-size: 20px;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            font-size: 12px;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 6px 8px;
            text-align: left;
            vertical-align: top;
        }
        th {
            background: #f3f4f6;
        }
    </style>
</head>
<body>
    <h1>CDD Samples</h1>
    <table>
<thead>
    <tr>
        <th>Reaction</th>
        <th>Name</th>
        <th>Location</th>
        <th>Concentration</th>
        <th>Purity</th>
        <th>Solvent</th>
        <th>Internal ID</th>
    </tr>
</thead>
        <tbody>
            ${rowsHtml}
        </tbody>
    </table>
</body>
</html>
`;
  window.postMessage({
    source: EVENT_SOURCE,
    type: "PRINT_REQUEST",
    payload: { html }
  }, "*");
}
function makePanelDraggable(panel) {
  const header = panel.querySelector(".cdd-stoich-header");
  if (!header) return;
  let isDragging = false;
  let startX = 0;
  let startY = 0;
  let startLeft = 0;
  let startTop = 0;
  header.addEventListener("mousedown", (event) => {
    if (event.target.closest("button")) return;
    isDragging = true;
    const rect = panel.getBoundingClientRect();
    panel.style.left = `${rect.left}px`;
    panel.style.top = `${rect.top}px`;
    panel.style.right = "auto";
    startX = event.clientX;
    startY = event.clientY;
    startLeft = rect.left;
    startTop = rect.top;
    document.body.style.userSelect = "none";
    event.preventDefault();
  });
  document.addEventListener("mousemove", (event) => {
    if (!isDragging) return;
    const dx = event.clientX - startX;
    const dy = event.clientY - startY;
    let newLeft = startLeft + dx;
    let newTop = startTop + dy;
    const maxLeft = window.innerWidth - panel.offsetWidth;
    const maxTop = window.innerHeight - panel.offsetHeight;
    newLeft = Math.max(0, Math.min(newLeft, maxLeft));
    newTop = Math.max(0, Math.min(newTop, maxTop));
    panel.style.left = `${newLeft}px`;
    panel.style.top = `${newTop}px`;
  });
  document.addEventListener("mouseup", () => {
    if (!isDragging) return;
    isDragging = false;
    document.body.style.userSelect = "";
  });
}
function ensurePanel() {
  if (!STATE.hasReactionFeature) return null;
  let panel = document.getElementById(PANEL_ID);
  if (panel) return panel;
  panel = document.createElement("div");
  panel.id = PANEL_ID;
  panel.style.top = "16px";
  panel.style.right = "16px";
  panel.style.left = "auto";
  const header = document.createElement("div");
  header.className = "cdd-stoich-header";
  const title = document.createElement("div");
  title.className = "cdd-stoich-title";
  title.textContent = "CDD Samples";
  const actions = document.createElement("div");
  actions.className = "cdd-stoich-actions";
  const refreshBtn = document.createElement("button");
  refreshBtn.id = `${PANEL_ID}-refresh`;
  refreshBtn.type = "button";
  refreshBtn.textContent = "Refresh";
  const printBtn = document.createElement("button");
  printBtn.id = `${PANEL_ID}-print`;
  printBtn.type = "button";
  printBtn.textContent = "Print";
  const toggleBtn = document.createElement("button");
  toggleBtn.id = `${PANEL_ID}-toggle`;
  toggleBtn.type = "button";
  toggleBtn.textContent = "−";
  actions.appendChild(refreshBtn);
  actions.appendChild(printBtn);
  actions.appendChild(toggleBtn);
  header.appendChild(title);
  header.appendChild(actions);
  const body = document.createElement("div");
  body.className = "cdd-stoich-body";
  const status = document.createElement("div");
  status.className = "cdd-stoich-status";
  status.textContent = "Waiting for reaction data...";
  const list = document.createElement("div");
  list.className = "cdd-stoich-list";
  body.appendChild(status);
  body.appendChild(list);
  panel.appendChild(header);
  panel.appendChild(body);
  const style = document.createElement("style");
  style.textContent = `
  #${PANEL_ID} {
    position: fixed;
    top: 16px;
    right: 16px;
    width: 300px;
    max-height: calc(100vh - 32px);
    background: #111827;
    color: #f9fafb;
    border: 1px solid #374151;
    border-radius: 12px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.35);
    z-index: 2147483647;
    font-family: Arial, sans-serif;
    overflow: hidden;
  }

  #${PANEL_ID} .cdd-stoich-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 12px;
    background: #1f2937;
    border-bottom: 1px solid #374151;
    cursor: move;
    user-select: none;
  }

  #${PANEL_ID} .cdd-stoich-title {
    font-size: 14px;
    font-weight: 700;
  }

  #${PANEL_ID} .cdd-stoich-actions {
    display: flex;
    gap: 6px;
  }

  #${PANEL_ID} button {
    background: #374151;
    color: #f9fafb;
    border: 1px solid #4b5563;
    border-radius: 6px;
    padding: 4px 8px;
    font-size: 12px;
    cursor: pointer;
  }

  #${PANEL_ID} button:hover {
    background: #4b5563;
  }

  #${PANEL_ID} .cdd-stoich-body {
    padding: 10px;
    overflow: auto;
    max-height: calc(100vh - 90px);
  }

  #${PANEL_ID} .cdd-stoich-status {
    font-size: 12px;
    color: #cbd5e1;
    margin-bottom: 10px;
  }

  #${PANEL_ID} .cdd-stoich-list {
    display: flex;
    flex-direction: column;
    gap: 10px;
  }

  #${PANEL_ID} .cdd-stoich-group {
    border: 1px solid #374151;
    border-radius: 12px;
    overflow: hidden;
    background: #0b1220;
  }

  #${PANEL_ID} .cdd-stoich-group-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 8px 10px;
    font-size: 12px;
    font-weight: 700;
    border-bottom: 1px solid rgba(255,255,255,0.06);
  }

  #${PANEL_ID} .cdd-stoich-group-count {
    font-size: 11px;
    opacity: 0.85;
  }

  #${PANEL_ID} .cdd-stoich-group-body {
    display: flex;
    flex-direction: column;
    gap: 8px;
    padding: 8px;
  }

  #${PANEL_ID} .cdd-stoich-card {
    border: 1px solid #374151;
    border-left-width: 4px;
    border-radius: 10px;
    padding: 10px;
    background: #0f172a;
  }

  #${PANEL_ID} .cdd-stoich-card-top {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 8px;
    margin-bottom: 6px;
  }

  #${PANEL_ID} .cdd-stoich-reaction-badge {
    display: inline-block;
    font-size: 10px;
    font-weight: 700;
    padding: 2px 6px;
    border-radius: 999px;
  }

  #${PANEL_ID} .cdd-stoich-row {
    margin-bottom: 4px;
    font-size: 12px;
    line-height: 1.4;
    word-break: break-word;
  }

  #${PANEL_ID} .cdd-stoich-row:last-child {
    margin-bottom: 0;
  }

  #${PANEL_ID} .cdd-stoich-label {
    color: #93c5fd;
    font-weight: 700;
  }

  #${PANEL_ID} .cdd-stoich-row-copyable {
    font-size: 12px;
    margin-bottom: 6px;
    line-height: 1.4;
    word-break: break-word;
  }

  #${PANEL_ID} .cdd-stoich-copy-value {
    cursor: pointer;
    margin-left: 6px;
    color: #f9fafb;
    padding: 1px 4px;
    border-radius: 4px;
  }

  #${PANEL_ID} .cdd-stoich-copy-value:hover {
    background: rgba(255,255,255,0.08);
  }

  #${PANEL_ID} .cdd-copy-flash {
    background: rgba(52, 211, 153, 0.35);
  }

  #${PANEL_ID}.collapsed .cdd-stoich-body {
    display: none;
  }

  #${PANEL_ID} .cdd-low-purity-badge {
    background: rgba(239, 68, 68, 0.15);
    color: #ef4444;
    font-weight: 700;
    font-size: 10px;
    padding: 2px 6px;
    border-radius: 999px;
    border: 1px solid rgba(239, 68, 68, 0.35);
  }
`;
  document.documentElement.appendChild(style);
  document.documentElement.appendChild(panel);
  makePanelDraggable(panel);
  refreshBtn.addEventListener("click", () => {
    renderFromState();
  });
  printBtn.addEventListener("click", () => {
    printPanel();
  });
  toggleBtn.addEventListener("click", () => {
    panel.classList.toggle("collapsed");
    toggleBtn.textContent = panel.classList.contains("collapsed") ? "+" : "−";
  });
  updatePanelVisibilityForOverlays();
  return panel;
}
function removePanel() {
  const panel = document.getElementById(PANEL_ID);
  if (panel) panel.remove();
}
function getPanelParts() {
  const panel = ensurePanel();
  if (!panel) {
    return {
      panel: null,
      status: null,
      list: null
    };
  }
  return {
    panel,
    status: panel.querySelector(".cdd-stoich-status"),
    list: panel.querySelector(".cdd-stoich-list")
  };
}
function parsePurity(value) {
  if (value == null || value === "") return NaN;
  return parseFloat(String(value).replace(",", "."));
}
function formatClipboardNumber(value) {
  if (!Number.isFinite(value)) return null;
  const rounded = Number(value.toFixed(12));
  if (Object.is(rounded, -0)) return "0";
  return String(rounded);
}
function normalizeConcentrationUnit(unit) {
  return String(unit || "").trim().replace(/\s+/g, "").replace(/μ/g, "u").replace(/µ/g, "u").toLowerCase();
}
function getCddCompatibleConcentrationCopyValue(sample) {
  const rawValue = sample?.concentration;
  const rawUnits = sample?.concentrationUnits;
  if (rawValue == null || rawValue === "") return null;
  const numericValue = parseFloat(String(rawValue).replace(",", "."));
  if (!Number.isFinite(numericValue)) {
    return rawUnits ? `${rawValue} ${rawUnits}` : String(rawValue);
  }
  const unit = normalizeConcentrationUnit(rawUnits);
  if (!unit) {
    return String(rawValue);
  }
  if (unit === "m" || unit === "mol/l") {
    return `${formatClipboardNumber(numericValue)} mol/L`;
  }
  if (unit === "mm" || unit === "mmol/l") {
    return `${formatClipboardNumber(numericValue)} mmol/L`;
  }
  if (unit === "um" || unit === "umol/l") {
    return `${formatClipboardNumber(numericValue / 1e3)} mmol/L`;
  }
  if (unit === "nm" || unit === "nmol/l") {
    return `${formatClipboardNumber(numericValue / 1e6)} mmol/L`;
  }
  if (unit === "mol/ml") {
    return `${formatClipboardNumber(numericValue)} mol/mL`;
  }
  return rawUnits ? `${rawValue} ${rawUnits}` : String(rawValue);
}
function createCopyableRow(label, value, options = {}) {
  if (value == null || value === "") return null;
  const row = document.createElement("div");
  row.className = "cdd-stoich-row-copyable";
  const labelEl = document.createElement("span");
  labelEl.className = "cdd-stoich-label";
  labelEl.textContent = `${label}:`;
  const valueEl = document.createElement("span");
  valueEl.className = "cdd-stoich-copy-value";
  const valueText = String(value);
  const copyText2 = options.copyValue != null && options.copyValue !== "" ? String(options.copyValue) : valueText;
  valueEl.textContent = valueText;
  row.appendChild(labelEl);
  row.appendChild(document.createTextNode(" "));
  row.appendChild(valueEl);
  if (options.highlight) {
    valueEl.style.color = "#ef4444";
    valueEl.style.fontWeight = "700";
  }
  valueEl.addEventListener("click", async () => {
    await copyTextWithFeedback(valueEl, copyText2);
  });
  return row;
}
function setStatus(text) {
  const { status } = getPanelParts();
  if (!status) return;
  status.textContent = text;
}
function getReactionColor(index) {
  return REACTION_COLORS[index % REACTION_COLORS.length];
}
function groupSamplesByReaction(samples) {
  const groups = /* @__PURE__ */ new Map();
  for (const sample of samples) {
    const key = sample.reactionIndex ?? 0;
    if (!groups.has(key)) {
      groups.set(key, {
        reactionIndex: key,
        reactionLabel: sample.reactionLabel || `Reaction ${key + 1}`,
        items: []
      });
    }
    groups.get(key).items.push(sample);
  }
  return [...groups.values()].sort((a, b) => a.reactionIndex - b.reactionIndex);
}
function formatConcentration(sample) {
  if (sample.concentration == null || sample.concentration === "") return null;
  if (sample.concentrationUnits) {
    return `${sample.concentration} ${sample.concentrationUnits}`;
  }
  return String(sample.concentration);
}
function isRenderableTextValue(value) {
  if (value == null) {
    return false;
  }
  if (typeof value === "object") {
    return false;
  }
  const text = String(value).trim();
  if (text === "") {
    return false;
  }
  return true;
}
function normalizeValue$1(value) {
  return String(value || "").replace(/\s+/g, " ").trim();
}
function isSampleDepleted(sample) {
  const depleted = STATE.depletedIdentifiers instanceof Set ? STATE.depletedIdentifiers : /* @__PURE__ */ new Set();
  const candidates = [
    sample?.name,
    sample?.sampleId,
    sample?.internalID
  ].map(normalizeValue$1).filter(Boolean);
  for (const candidate of candidates) {
    if (depleted.has(candidate)) {
      return true;
    }
  }
  return false;
}
function renderSamples(payload) {
  const { list } = getPanelParts();
  if (!list) return;
  list.replaceChildren();
  const samples = payload?.samples || [];
  if (!samples.length) {
    const emptyCard = document.createElement("div");
    emptyCard.className = "cdd-stoich-card";
    emptyCard.textContent = "No samples found in reaction block.";
    list.appendChild(emptyCard);
    return;
  }
  const groups = groupSamplesByReaction(samples);
  for (const group of groups) {
    const color = getReactionColor(group.reactionIndex);
    const groupEl = document.createElement("div");
    groupEl.className = "cdd-stoich-group";
    groupEl.style.borderColor = color.border;
    groupEl.style.boxShadow = `0 0 0 1px ${color.glow} inset`;
    const groupHeader = document.createElement("div");
    groupHeader.className = "cdd-stoich-group-header";
    groupHeader.style.background = color.badgeBg;
    groupHeader.style.color = color.badgeText;
    const groupTitle = document.createElement("span");
    groupTitle.textContent = group.reactionLabel;
    const groupCount = document.createElement("span");
    groupCount.className = "cdd-stoich-group-count";
    groupCount.textContent = `${group.items.length} sample(s)`;
    groupHeader.appendChild(groupTitle);
    groupHeader.appendChild(groupCount);
    const groupBody = document.createElement("div");
    groupBody.className = "cdd-stoich-group-body";
    for (const sample of group.items) {
      const card = document.createElement("div");
      card.className = "cdd-stoich-card";
      card.style.borderLeftColor = color.border;
      card.style.boxShadow = `0 0 0 1px ${color.glow} inset`;
      const concentrationText = formatConcentration(sample);
      const purityValue = parsePurity(sample.purity);
      const lowPurity = !isNaN(purityValue) && purityValue <= 93;
      const depletedSample = isSampleDepleted(sample);
      const { internalID, solvent } = sample;
      if (lowPurity || depletedSample) {
        card.style.borderLeftColor = "#ef4444";
        card.style.background = "rgba(239,68,68,0.05)";
      }
      const cardTop = document.createElement("div");
      cardTop.className = "cdd-stoich-card-top";
      const badge = document.createElement("div");
      badge.className = "cdd-stoich-reaction-badge";
      badge.style.background = color.badgeBg;
      badge.style.color = color.badgeText;
      badge.textContent = group.reactionLabel;
      cardTop.appendChild(badge);
      if (lowPurity) {
        const purityBadge = document.createElement("div");
        purityBadge.className = "cdd-low-purity-badge";
        purityBadge.textContent = "⚠ LOW PURITY";
        cardTop.appendChild(purityBadge);
      }
      if (depletedSample) {
        const depletedBadge = document.createElement("div");
        depletedBadge.className = "cdd-low-purity-badge";
        depletedBadge.textContent = "⚠ DEPLETED SAMPLE USED";
        cardTop.appendChild(depletedBadge);
      }
      card.appendChild(cardTop);
      const purityRow = lowPurity ? createCopyableRow("Purity [%]", sample.purity, { highlight: true }) : null;
      const rows = [
        createCopyableRow("Name", sample.name || "—"),
        isRenderableTextValue(sample.location) ? createCopyableRow("Location", sample.location) : null,
        purityRow,
        createCopyableRow("Internal ID", internalID),
        createCopyableRow("Density [g/mL]", sample.density),
        createCopyableRow("Concentration", concentrationText, {
          copyValue: getCddCompatibleConcentrationCopyValue(sample)
        }),
        createCopyableRow("Solvent", solvent)
      ].filter(Boolean);
      for (const rowEl of rows) {
        card.appendChild(rowEl);
      }
      groupBody.appendChild(card);
    }
    groupEl.appendChild(groupHeader);
    groupEl.appendChild(groupBody);
    list.appendChild(groupEl);
  }
}
function renderFromState() {
  if (!isElnEntryPage()) return;
  if (!STATE.hasReactionFeature) return;
  if (STATE.isKetcherOpen) return;
  ensurePanel();
  if (!STATE.lastPayload) {
    setStatus("No reaction data captured yet. Wait for page API response.");
    return;
  }
  const count = STATE.lastPayload.samples?.length || 0;
  const reactionCount = STATE.lastPayload.reactionCount || 0;
  setStatus(`Loaded ${count} sample(s) from ${reactionCount} reaction(s).`);
  renderSamples(STATE.lastPayload);
}
const BTN_CLASS = "cdd-stoich-print-button";
const BTN_ATTR = "data-cdd-stoich-print-button";
function formatNumber(value, digits = 2) {
  if (value == null || value === "") return "—";
  const num = Number(value);
  if (Number.isNaN(num)) return String(value);
  return num.toFixed(digits);
}
function formatMass(value) {
  if (value == null || value === "") return "—";
  const num = Number(value);
  if (Number.isNaN(num)) return escapeHtml(String(value));
  if (num < 0.1) {
    return `${formatNumber(num * 1e3, 2)} mg`;
  }
  return `${formatNumber(num, 3)} g`;
}
function formatMmol(value) {
  if (value == null || value === "") {
    return "—";
  }
  const num = Number(value);
  if (Number.isNaN(num)) {
    return "—";
  }
  const abs = Math.abs(num);
  let result;
  let unit;
  if (abs >= 1e-3) {
    result = (num * 1e3).toFixed(2);
    unit = "mmol";
  } else if (abs >= 1e-6) {
    result = (num * 1e6).toFixed(2);
    unit = "µmol";
  } else if (abs >= 1e-9) {
    result = (num * 1e9).toFixed(2);
    unit = "nmol";
  } else {
    result = num.toExponential(2);
    unit = "mol";
  }
  return `${result} ${unit}`;
}
function formatVolume(value) {
  if (value == null || value === "") return "—";
  const num = Number(value);
  if (Number.isNaN(num)) return String(value);
  const ml = num * 1e3;
  if (ml >= 1) {
    return `${formatNumber(ml, 3)} mL`;
  } else {
    const ul = ml * 1e3;
    return `${formatNumber(ul, 3)} µL`;
  }
}
function normalizeName(str) {
  if (!str) return "";
  return String(str).toLowerCase().replace(/\s+/g, " ").trim();
}
function buildRowsHtml(rows) {
  return rows.map((row, index) => {
    const fw = row.formulaWeight ?? row.molecularWeight;
    const exactMass = row.exactMass;
    const mass = row.mass;
    const volume = row.volume;
    const equivalent = row.equivalent;
    const limiting = row.limitingReagent;
    const mole = row.mole;
    const effectiveMole = row.effectiveMole;
    const yieldValue = row.yield;
    const showIupac = row.subtitle && normalizeName(row.subtitle) !== normalizeName(row.name);
    const nameClass = row.depleted ? "name-main depleted" : "name-main";
    return `
          <tr class="main-row">
            <td class="col-name compact-name">
              <div class="row-index">${index + 1}</div>
              <div class="${nameClass}">${escapeHtml(row.name || "Unnamed")}</div>
            </td>

            <td class="col-properties">
              ${fw != null && fw !== "" ? `<div><strong>FW:</strong> ${formatNumber(fw, 2)} g/mol</div>` : ""}
              ${exactMass != null && exactMass !== "" ? `<div class="muted">Exact mass: ${formatNumber(exactMass, 6)} Da</div>` : ""}
              ${row.density != null && row.density !== "" ? `<div class="muted">Density: ${formatNumber(row.density, 3)} g/cm³</div>` : ""}
              ${row.boilingPoint != null && row.boilingPoint !== "" ? `<div class="muted">Boiling point: ${formatNumber(row.boilingPoint, 0)} °C</div>` : ""}
            </td>

            <td class="col-amounts">
              ${mass != null && mass !== "" ? `<div><strong>Mass:</strong> ${formatMass(mass)}</div>` : ""}
              ${volume != null && volume !== "" ? `<div><strong>Volume:</strong> ${formatVolume(volume)}</div>` : ""}
            </td>

            <td class="col-calculation">
              ${limiting ? `<div><strong>Limiting reagent</strong></div>` : ""}
              ${equivalent != null && equivalent !== "" ? `<div><strong>Equivalent:</strong> ${formatNumber(equivalent, 2)}</div>` : ""}
              ${mole != null && mole !== "" ? `<div><strong>Mole:</strong> ${formatMmol(mole)}</div>` : ""}
              ${effectiveMole != null && effectiveMole !== "" ? `<div class="muted">Effective mole: ${formatMmol(effectiveMole)}</div>` : ""}
              ${yieldValue != null && yieldValue !== "" ? `<div class="muted">Yield: ${formatNumber(yieldValue, 2)} %</div>` : ""}
            </td>
          </tr>

<tr class="details-row">
  <td colspan="4" class="row-details">
    <div class="location-line">
      <strong>Location:</strong> ${escapeHtml(row.location || "Location not set")}
    </div>

    ${showIupac ? `<div class="muted" style="margin-top:2px;">
             <strong>IUPAC:</strong> ${escapeHtml(row.subtitle)}
           </div>` : ""}
  </td>
</tr>
        `;
  }).join("");
}
function buildPrintHtml(reactionPayload) {
  const reactionIndex = Number(reactionPayload?.reactionIndex ?? 0);
  const title = escapeHtml(reactionPayload?.title || "Stoichiometry Sheet");
  const identifier = escapeHtml(reactionPayload?.identifier || "Unknown experiment");
  const rows = Array.isArray(reactionPayload?.rows) ? reactionPayload.rows : [];
  const domReactionImageHtml = getReactionImageHtmlForIndex(reactionIndex);
  const imageHtml = domReactionImageHtml ? `<div class="scheme">${domReactionImageHtml}</div>` : "";
  const rowsHtml = buildRowsHtml(rows);
  return `
      <html lang="en">
        <head>
          <meta charset="UTF-8" />
          <title>${identifier} - ${title}</title>
          <style>
            @page {
              size: A4 portrait;
              margin: 12mm;
            }

            body {
              font-family: Arial, sans-serif;
              color: #111;
              margin: 0;
              padding: 0;
            }

            .page {
              width: 100%;
            }

            .header {
              display: flex;
              justify-content: space-between;
              align-items: flex-start;
              gap: 16px;
              margin-bottom: 8px;
            }

            .header-left {
              flex: 1;
              min-width: 0;
            }

            .header-right {
              flex: 0 0 auto;
              text-align: right;
              padding-left: 16px;
            }

            .title {
              font-size: 18px;
              font-weight: 700;
              margin-bottom: 2px;
              line-height: 1.2;
              word-break: break-word;
            }

            .experiment-label {
              font-size: 10px;
              text-transform: uppercase;
              letter-spacing: 0.08em;
              color: #6b7280;
              margin-bottom: 2px;
            }

            .experiment-id {
              font-size: 15px;
              font-weight: 700;
              color: #111827;
              line-height: 1.2;
            }

            .meta {
              font-size: 11px;
              color: #666;
              margin-bottom: 14px;
            }

            .scheme {
              border: 1px solid #d1d5db;
              border-radius: 8px;
              padding: 10px 12px;
              margin-bottom: 14px;
              page-break-inside: avoid;
            }

            .scheme img {
              width: 100%;
              height: auto;
              display: block;
            }

            table {
              width: 100%;
              border-collapse: collapse;
              table-layout: fixed;
            }

            thead {
              display: table-header-group;
            }

            .main-row {
              border-top: 1px solid #d1d5db;
            }

            .details-row {
              border-top: none;
            }

            th, td {
              padding: 10px 8px;
              font-size: 12px;
              text-align: left;
              vertical-align: top;
            }

            th {
              font-size: 12px;
              font-weight: 700;
              border-bottom: 1px solid #9ca3af;
            }

            .col-name { width: 24%; }
            .col-properties { width: 26%; }
            .col-amounts { width: 20%; }
            .col-calculation { width: 30%; }

            .compact-name .row-index {
              float: left;
              width: 18px;
              color: #444;
            }

            .compact-name .name-main {
              font-weight: 700;
              color: #1d4ed8;
              margin-left: 22px;
              line-height: 1.2;
              word-break: break-word;
            }

            .row-details {
              padding-top: 0;
              padding-left: 30px;
              padding-bottom: 8px;
            }

            .location-line {
              margin-top: 0;
              margin-bottom: 1px;
              font-size: 11px;
              color: #1f2937;
              line-height: 1.15;
              word-break: break-word;
            }

            .muted {
              color: #6b7280;
              margin-top: 1px;
              line-height: 1.2;
            }

            .print-footer {
              margin-top: 24px;
              padding-top: 8px;
              border-top: 1px solid #d1d5db;
              font-size: 9px;
              color: #9ca3af;
              text-align: center;
            }
          </style>
        </head>
        <body>
          <div class="page">
           <div class="header">
  <div class="header-left">
    <div class="title">${title}</div>
  </div>
  <div class="header-right">
    <div class="experiment-label">Experiment ID</div>
    <div class="experiment-id">${identifier}</div>
  </div>
</div>

            <div class="meta">
              <div><strong>Source:</strong> ${escapeHtml(location.href)}</div>
              <div><strong>Printed:</strong> ${escapeHtml((/* @__PURE__ */ new Date()).toLocaleString())}</div>
              <div><strong>Reaction index:</strong> ${reactionIndex + 1}</div>
            </div>

            ${imageHtml}

            <table>
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Properties</th>
                  <th>Amounts</th>
                  <th>Calculation</th>
                </tr>
              </thead>
              <tbody>
                ${rowsHtml}
              </tbody>
            </table>

            <div class="print-footer">
              Custom print layout generated by CDD Stoichiometric Table Tools. Written by Matus Drexler, IOCB Prague & PharmTheon
            </div>
          </div>
        </body>
      </html>
    `;
}
function getReactionPayload(index) {
  if (!Array.isArray(STATE.reactionPayloads)) return null;
  return STATE.reactionPayloads.find(
    (item) => Number(item?.reactionIndex) === Number(index)
  ) || null;
}
function getReactionElements() {
  const exact = Array.from(
    document.querySelectorAll('[data-autotest-id="reaction"]')
  );
  if (exact.length) return exact;
  const selectors = [
    '[data-feature-type="reaction"]',
    '[data-testid*="reaction"]',
    ".reaction",
    ".reaction-block",
    ".eln-reaction",
    ".stoichiometry-table"
  ];
  const matched = [];
  const seen = /* @__PURE__ */ new Set();
  for (const selector of selectors) {
    document.querySelectorAll(selector).forEach((el) => {
      if (seen.has(el)) return;
      seen.add(el);
      matched.push(el);
    });
  }
  return matched;
}
function buildButton(reactionIndex) {
  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = BTN_CLASS;
  btn.setAttribute(BTN_ATTR, "1");
  btn.dataset.reactionIndex = String(reactionIndex);
  btn.title = "Print stoichiometry sheet";
  btn.setAttribute("aria-label", "Print stoichiometry sheet");
  const svgNs = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(svgNs, "svg");
  svg.setAttribute("viewBox", "0 0 24 24");
  svg.setAttribute("width", "16");
  svg.setAttribute("height", "16");
  svg.setAttribute("aria-hidden", "true");
  const path = document.createElementNS(svgNs, "path");
  path.setAttribute(
    "d",
    "M6 9V4h12v5h1a2 2 0 0 1 2 2v5h-3v4H6v-4H3v-5a2 2 0 0 1 2-2h1zm2-3v3h8V6H8zm8 12v-4H8v4h8zm2-7H6a1 1 0 0 0-1 1v2h1v-2h12v2h1v-2a1 1 0 0 0-1-1z"
  );
  path.setAttribute("fill", "currentColor");
  svg.appendChild(path);
  btn.appendChild(svg);
  svg.style.display = "block";
  svg.style.width = "14px";
  svg.style.height = "14px";
  svg.style.flexShrink = "0";
  btn.style.position = "absolute";
  btn.style.top = "8px";
  btn.style.right = "70px";
  btn.style.width = "28px";
  btn.style.height = "25px";
  btn.style.minWidth = "20px";
  btn.style.minHeight = "20px";
  btn.style.display = "inline-flex";
  btn.style.alignItems = "center";
  btn.style.justifyContent = "center";
  btn.style.padding = "0";
  btn.style.margin = "0";
  btn.style.boxSizing = "border-box";
  btn.style.border = "1px solid #d1d5db";
  btn.style.borderRadius = "8px";
  btn.style.background = "#ffffff";
  btn.style.color = "#6b7280";
  btn.style.cursor = "pointer";
  btn.style.zIndex = "20";
  btn.style.verticalAlign = "middle";
  btn.style.lineHeight = "1";
  btn.style.boxShadow = "0 1px 2px rgba(0,0,0,0.08)";
  btn.style.transition = "background 0.15s ease, border-color 0.15s ease, color 0.15s ease, box-shadow 0.15s ease";
  btn.addEventListener("mouseenter", () => {
    btn.style.background = "#f9fafb";
    btn.style.borderColor = "#bfc6cf";
    btn.style.color = "#374151";
    btn.style.boxShadow = "0 1px 3px rgba(0,0,0,0.12)";
  });
  btn.addEventListener("mouseleave", () => {
    btn.style.background = "#ffffff";
    btn.style.borderColor = "#d1d5db";
    btn.style.color = "#6b7280";
    btn.style.boxShadow = "0 1px 2px rgba(0,0,0,0.08)";
  });
  btn.addEventListener("focus", () => {
    btn.style.outline = "2px solid #93c5fd";
    btn.style.outlineOffset = "1px";
  });
  btn.addEventListener("blur", () => {
    btn.style.outline = "none";
  });
  btn.addEventListener("click", (event) => {
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
    printStoichiometrySheet(reactionIndex);
  }, true);
  return btn;
}
function printStoichiometrySheet(reactionIndex) {
  const payload = getReactionPayload(reactionIndex);
  if (!payload?.rows?.length) {
    alert("No stoichiometry data available yet for this reaction.");
    return;
  }
  const html = buildPrintHtml(payload);
  window.postMessage({
    source: EVENT_SOURCE,
    type: "PRINT_REQUEST",
    payload: { html }
  }, "*");
}
function ensurePrintButtons() {
  const reactionElements = getReactionElements();
  if (!reactionElements.length) return;
  ensurePrintButtonStyles();
  reactionElements.forEach((reactionEl, index) => {
    reactionEl.classList.add("cdd-stoich-reaction-host");
    const existing = reactionEl.querySelector(
      `.${BTN_CLASS}[data-reaction-index="${index}"]`
    );
    if (existing) return;
    const payload = getReactionPayload(index);
    if (!payload) return;
    const computed = window.getComputedStyle(reactionEl);
    if (computed.position === "static") {
      reactionEl.style.position = "relative";
    }
    const button = buildButton(index);
    reactionEl.appendChild(button);
  });
}
function getReactionImageHtmlForIndex(reactionIndex) {
  const reactions = getReactionElements();
  const reaction = reactions[reactionIndex];
  if (!reaction) return "";
  let img = reaction.querySelector(".ChemistryImage img");
  if (!img) {
    const imageContainer = reaction.querySelector('[data-autotest-id="inline-container--image"]');
    if (imageContainer) {
      img = imageContainer.querySelector("img");
    }
  }
  if (!img) return "";
  return img.outerHTML;
}
function ensurePrintButtonStyles() {
  if (document.getElementById("cdd-stoich-print-button-styles")) return;
  const style = document.createElement("style");
  style.id = "cdd-stoich-print-button-styles";
  style.textContent = `
        .cdd-stoich-reaction-host .${BTN_CLASS} {
            opacity: 0;
            pointer-events: none;
            transform: translateY(-2px);
            transition: opacity 0.15s ease, transform 0.15s ease;
        }

        .cdd-stoich-reaction-host:hover .${BTN_CLASS},
        .cdd-stoich-reaction-host:focus-within .${BTN_CLASS} {
            opacity: 1;
            pointer-events: auto;
            transform: translateY(0);
        }
    `;
  document.head.appendChild(style);
}
const OBSERVER_KEY = "__CDD_DEPLETED_OBSERVER__";
const STYLE_ID = "cdd-depleted-style";
function normalizeValue(value) {
  return String(value || "").replace(/\s+/g, " ").trim();
}
function getDepletedSet() {
  const raw = STATE.depletedIdentifiers instanceof Set ? Array.from(STATE.depletedIdentifiers) : Array.isArray(STATE.depletedIdentifiers) ? STATE.depletedIdentifiers : [];
  return new Set(raw.map(normalizeValue).filter(Boolean));
}
function ensureDepletedStyle() {
  if (document.getElementById(STYLE_ID)) return;
  const style = document.createElement("style");
  style.id = STYLE_ID;
  style.textContent = `
.cdd-depleted-sample {
    opacity: 0.5 !important;
}

.cdd-depleted-sample,
.cdd-depleted-sample * {
    text-decoration: line-through !important;
    color: #9ca3af !important;
}
    `;
  document.documentElement.appendChild(style);
}
function wrapperMatchesDepleted(wrapper, depleted) {
  const text = normalizeValue(wrapper?.innerText || wrapper?.textContent || "");
  if (!text) return false;
  for (const id of depleted) {
    if (text.includes(id)) return true;
  }
  return false;
}
function markDepletedSamplesInSelector() {
  ensureDepletedStyle();
  const depleted = getDepletedSet();
  document.querySelectorAll('input[type="radio"][value]').forEach((input) => {
    const value = normalizeValue(input.value);
    const wrapper = input.closest('[data-autotest-id="radio-button"]')?.parentElement || input.closest('[data-component="Box"]') || input.parentElement;
    if (!wrapper) return;
    normalizeValue(wrapper.innerText || wrapper.textContent || "");
    const directMatch = depleted.has(value);
    const textMatch = !directMatch && wrapperMatchesDepleted(wrapper, depleted);
    const matched = directMatch || textMatch;
    wrapper.classList.toggle("cdd-depleted-sample", matched);
  });
}
function startDepletedMarkerObserver() {
  if (window[OBSERVER_KEY]) return;
  let scheduled = false;
  const rerun = () => {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(() => {
      scheduled = false;
      markDepletedSamplesInSelector();
    });
  };
  const observer = new MutationObserver(() => {
    rerun();
  });
  observer.observe(document.documentElement, {
    childList: true,
    subtree: true
  });
  window[OBSERVER_KEY] = observer;
  rerun();
}
function handleMessage(event) {
  if (event.source !== window) return;
  const data = event.data;
  if (!data || data.source !== EVENT_SOURCE) return;
  switch (data.type) {
    case "REACTION_VISIBILITY": {
      STATE.hasReactionFeature = !!data.payload?.visible;
      if (!STATE.hasReactionFeature) {
        removePanel();
      } else {
        renderFromState();
      }
      break;
    }
    case "SAMPLE_DATA": {
      STATE.lastPayload = data.payload || null;
      renderFromState();
      break;
    }
    case "PRINT_DATA": {
      STATE.reactionPayloads = Array.isArray(data.payload?.reactionPayloads) ? data.payload.reactionPayloads : [];
      const incoming = Array.isArray(data.payload?.depletedIdentifiers) ? data.payload.depletedIdentifiers : [];
      if (incoming.length > 0) {
        const next = new Set(STATE.depletedIdentifiers || []);
        for (const id of incoming) {
          const normalized = String(id || "").replace(/\s+/g, " ").trim();
          if (normalized) next.add(normalized);
        }
        STATE.depletedIdentifiers = next;
      }
      setTimeout(() => {
        ensurePrintButtons();
        markDepletedSamplesInSelector();
      }, 50);
      break;
    }
  }
}
function watchUrlChanges(onChange) {
  const check = () => {
    if (location.href === STATE.lastUrl) return;
    STATE.lastUrl = location.href;
    if (typeof onChange === "function") {
      onChange(location.href);
    }
  };
  const observer = new MutationObserver(check);
  observer.observe(document.documentElement, {
    childList: true,
    subtree: true
  });
  setInterval(check, 700);
}
function isSupportedHost() {
  return /collaborativedrug\.com/i.test(location.hostname);
}
function init() {
  if (!isSupportedHost()) return;
  if (window.__CDD_STOICH_TOOLS_CONTENT__) return;
  window.__CDD_STOICH_TOOLS_CONTENT__ = true;
  injectPageScript();
  window.addEventListener("message", handleMessage);
  ensurePanel();
  ensureDepletedStyle();
  startDepletedMarkerObserver();
  renderFromState();
  ensurePrintButtons();
  markDepletedSamplesInSelector();
  watchUrlChanges(() => {
    resetState();
    ensurePanel();
    renderFromState();
    ensurePrintButtons();
    markDepletedSamplesInSelector();
  });
  watchKetcherDialog();
}
init();
